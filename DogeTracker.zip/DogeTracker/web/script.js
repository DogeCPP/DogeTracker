// ============================================================
// DogeTracker v3  –  script.js
//
// Phase 1 : Live lat/lon, map, poll
// Phase 2 : Heading, pitch/roll ADI, wind rose, IAS/VS/AGL,
//           smooth lerp interpolation
// Phase 3 : SimBrief full route (waypoints, fuel, aircraft)
// T/D     : Time-based countdown alarm with Web Audio API
// ============================================================
'use strict';

// ── Config ───────────────────────────────────────────────────
const PORT    = 4000;
const POLL_MS = 1000;
const LERP_FPS = 60;

// ── State ────────────────────────────────────────────────────
let currentPos = null, lerpFrom = null, lerpTarget = null;
let lerpFrame = 0, rafId = null;
let trailPts = [], trailMax = 300, trailLine = null;
let acMarker = null, todMarker = null;
let routeLayer = null, simbriefRoute = null;
let followAc = true, showTrail = true, smoothLerp = true, showTodMarker = true;
let todAngle = 3.0;

// ── Alarm state ───────────────────────────────────────────────
let alarmArmed      = false;    // user pressed "Set Alarm"
let alarmDeadline   = null;     // Date object: when T/D happens
let alarmLeadMs     = 5*60000;  // fire alarm this many ms before T/D
let alarmFired      = false;    // alarm already played?
let alarmVolume     = 0.8;      // 0-1
let alarmSound      = 'beep';   // beep | chime | siren
let audioCtx        = null;     // Web Audio context (lazy init)
let alarmInterval   = null;     // setInterval for countdown tick
let alarmNode       = null;     // currently playing sound nodes

// ── Maths ────────────────────────────────────────────────────
const lerp   = (a,b,t) => a + (b-a)*t;
const clamp  = (v,lo,hi) => Math.max(lo, Math.min(hi, v));
const toRad  = d => d * Math.PI/180;
const toDeg  = r => r * 180/Math.PI;

function lerpHeading(a,b,t) {
    let d = ((b-a)+540)%360-180;
    return (a+d*t+360)%360;
}
function lerpState(a,b,t) {
    return {
        lat:             lerp(a.lat,             b.lat,             t),
        lon:             lerp(a.lon,             b.lon,             t),
        heading:         lerpHeading(a.heading,  b.heading,         t),
        pitch:           lerp(a.pitch,           b.pitch,           t),
        roll:            lerp(a.roll,            b.roll,            t),
        altitude_ft:     lerp(a.altitude_ft,     b.altitude_ft,     t),
        agl_ft:          lerp(a.agl_ft,          b.agl_ft,          t),
        groundspeed_kts: lerp(a.groundspeed_kts, b.groundspeed_kts, t),
        airspeed_kts:    lerp(a.airspeed_kts,    b.airspeed_kts,    t),
        vspeed_fpm:      lerp(a.vspeed_fpm,      b.vspeed_fpm,      t),
        wind_dir:        lerp(a.wind_dir,         b.wind_dir,        t),
        wind_spd_kts:    lerp(a.wind_spd_kts,    b.wind_spd_kts,    t),
    };
}

function distNM(lat1,lon1,lat2,lon2) {
    const R=3440.065, dL=toRad(lat2-lat1), dG=toRad(lon2-lon1);
    const a=Math.sin(dL/2)**2+Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dG/2)**2;
    return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
}
function bearing(lat1,lon1,lat2,lon2) {
    const dG=toRad(lon2-lon1);
    const y=Math.sin(dG)*Math.cos(toRad(lat2));
    const x=Math.cos(toRad(lat1))*Math.sin(toRad(lat2))-Math.sin(toRad(lat1))*Math.cos(toRad(lat2))*Math.cos(dG);
    return (toDeg(Math.atan2(y,x))+360)%360;
}
function destination(lat,lon,dist,brg) {
    const d=dist/3440.065, bR=toRad(brg), pR=toRad(lat);
    const nLat=Math.asin(Math.sin(pR)*Math.cos(d)+Math.cos(pR)*Math.sin(d)*Math.cos(bR));
    const nLon=toRad(lon)+Math.atan2(Math.sin(bR)*Math.sin(d)*Math.cos(pR),Math.cos(d)-Math.sin(pR)*Math.sin(nLat));
    return [toDeg(nLat),toDeg(nLon)];
}
function todDistNM(altFt,angleDeg) {
    return altFt/(Math.tan(toRad(angleDeg))*6076.12);
}

// ── DOM helper ────────────────────────────────────────────────
const $ = id => document.getElementById(id);

// ══════════════════════════════════════════════════════════════
// NEW PLANE ICON  – wide-body airliner top-down silhouette
// ══════════════════════════════════════════════════════════════
function makeAcIcon(hdg) {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg"
         width="48" height="48" viewBox="0 0 48 48">
  <g transform="rotate(${hdg},24,24)">
    <!-- Drop shadow -->
    <g transform="translate(1.5,1.5)" opacity="0.25">
      <!-- Fuselage -->
      <ellipse cx="24" cy="24" rx="3.5" ry="17" fill="#000"/>
      <!-- Left wing -->
      <path d="M22 22 L4 30 L6 32 L22 26 Z" fill="#000"/>
      <!-- Right wing -->
      <path d="M26 22 L44 30 L42 32 L26 26 Z" fill="#000"/>
      <!-- Left stabiliser -->
      <path d="M21 36 L13 41 L14 43 L22 39 Z" fill="#000"/>
      <!-- Right stabiliser -->
      <path d="M27 36 L35 41 L34 43 L26 39 Z" fill="#000"/>
    </g>

    <!-- Fuselage body -->
    <ellipse cx="24" cy="24" rx="3.5" ry="17"
             fill="url(#fuse-grad)" stroke="#1158c7" stroke-width="0.6"/>

    <!-- Left wing -->
    <path d="M22 22 L4 30 L6 32 L22 26 Z"
          fill="url(#wing-grad)" stroke="#1158c7" stroke-width="0.6"/>
    <!-- Right wing -->
    <path d="M26 22 L44 30 L42 32 L26 26 Z"
          fill="url(#wing-grad)" stroke="#1158c7" stroke-width="0.6"/>

    <!-- Engine pods -->
    <ellipse cx="13" cy="28" rx="2.2" ry="4.5" fill="#1f6feb" stroke="#1158c7" stroke-width="0.5"/>
    <ellipse cx="35" cy="28" rx="2.2" ry="4.5" fill="#1f6feb" stroke="#1158c7" stroke-width="0.5"/>

    <!-- Left stabiliser -->
    <path d="M21 36 L13 41 L14 43 L22 39 Z"
          fill="#1f6feb" stroke="#1158c7" stroke-width="0.5"/>
    <!-- Right stabiliser -->
    <path d="M27 36 L35 41 L34 43 L26 39 Z"
          fill="#1f6feb" stroke="#1158c7" stroke-width="0.5"/>

    <!-- Nose highlight -->
    <ellipse cx="24" cy="9" rx="2" ry="3" fill="rgba(255,255,255,0.35)"/>

    <!-- Cockpit windows -->
    <rect x="22.5" y="10.5" width="3" height="2.5" rx="1"
          fill="rgba(255,255,255,0.6)"/>

    <!-- Wing root line -->
    <line x1="22" y1="22" x2="22" y2="26" stroke="rgba(255,255,255,0.3)" stroke-width="0.4"/>
    <line x1="26" y1="22" x2="26" y2="26" stroke="rgba(255,255,255,0.3)" stroke-width="0.4"/>

    <!-- Doge gold nose dot -->
    <circle cx="24" cy="7.5" r="1.4" fill="#ffd700"/>

    <!-- Gradient defs -->
    <defs>
      <linearGradient id="fuse-grad" x1="0" x2="1" y1="0" y2="0">
        <stop offset="0%"   stop-color="#388bfd"/>
        <stop offset="50%"  stop-color="#58a6ff"/>
        <stop offset="100%" stop-color="#388bfd"/>
      </linearGradient>
      <linearGradient id="wing-grad" x1="0" x2="0" y1="0" y2="1">
        <stop offset="0%"   stop-color="#388bfd"/>
        <stop offset="100%" stop-color="#1f6feb"/>
      </linearGradient>
    </defs>
  </g>
</svg>`;
    return L.divIcon({
        html: `<div style="filter:drop-shadow(0 2px 4px rgba(0,0,0,0.5))">${svg}</div>`,
        className:   '',
        iconSize:    [48,48],
        iconAnchor:  [24,24],
        popupAnchor: [0,-28]
    });
}

// ══════════════════════════════════════════════════════════════
// WEB AUDIO ALARM ENGINE
// Three sounds: beep / chime / siren — all synthesised,
// no audio files needed.
// ══════════════════════════════════════════════════════════════
function getAudioCtx() {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    return audioCtx;
}

function stopAlarmSound() {
    if (alarmNode) {
        try { alarmNode.forEach(n => { n.stop && n.stop(); n.disconnect && n.disconnect(); }); } catch(_){}
        alarmNode = null;
    }
}

function playBeep(vol) {
    const ctx = getAudioCtx();
    const nodes = [];
    let t = ctx.currentTime;
    // 8 rapid beeps at 880 Hz
    for (let i = 0; i < 8; i++) {
        const osc  = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type      = 'sine';
        osc.frequency.value = 880;
        gain.gain.setValueAtTime(0, t + i*0.25);
        gain.gain.linearRampToValueAtTime(vol, t + i*0.25 + 0.01);
        gain.gain.linearRampToValueAtTime(0,   t + i*0.25 + 0.18);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t + i*0.25);
        osc.stop( t + i*0.25 + 0.20);
        nodes.push(osc, gain);
    }
    alarmNode = nodes;
    setTimeout(stopAlarmSound, 2500);
}

function playChime(vol) {
    const ctx = getAudioCtx();
    const notes = [523.25, 659.25, 783.99, 1046.5]; // C5 E5 G5 C6
    const nodes = [];
    notes.forEach((freq, i) => {
        const osc  = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type      = 'triangle';
        osc.frequency.value = freq;
        const t = ctx.currentTime + i*0.22;
        gain.gain.setValueAtTime(0, t);
        gain.gain.linearRampToValueAtTime(vol, t + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 1.2);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t);
        osc.stop(t + 1.3);
        nodes.push(osc, gain);
    });
    // Repeat twice
    setTimeout(() => playChime(vol * 0.85), 1400);
    alarmNode = nodes;
}

function playSiren(vol) {
    const ctx  = getAudioCtx();
    const osc  = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    gain.gain.value = vol * 0.5;
    // Sweep 400→1200 Hz over 0.6s, loop
    const sweep = () => {
        osc.frequency.cancelScheduledValues(ctx.currentTime);
        osc.frequency.setValueAtTime(400, ctx.currentTime);
        osc.frequency.linearRampToValueAtTime(1200, ctx.currentTime + 0.5);
        osc.frequency.linearRampToValueAtTime(400,  ctx.currentTime + 1.0);
    };
    sweep();
    const sweepTimer = setInterval(sweep, 1000);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    alarmNode = [osc, gain];
    // Auto-stop after 5s
    setTimeout(() => {
        clearInterval(sweepTimer);
        stopAlarmSound();
    }, 5000);
}

function playAlarmSound() {
    stopAlarmSound();
    const vol = alarmVolume;
    if      (alarmSound === 'beep')  playBeep(vol);
    else if (alarmSound === 'chime') playChime(vol);
    else                             playSiren(vol);
}

// ══════════════════════════════════════════════════════════════
// COUNTDOWN / ALARM LOGIC
// ══════════════════════════════════════════════════════════════
const RING_CIRC = 326.7; // 2π×52

function updateCountdownUI() {
    if (!alarmArmed || !alarmDeadline) return;

    const now       = Date.now();
    const msToTod   = alarmDeadline - now;
    const msToAlarm = alarmDeadline - alarmLeadMs - now;
    const totalMs   = alarmDeadline - alarmDeadline + (alarmDeadline - (alarmDeadline - alarmLeadMs)); // = alarmLeadMs
    // Actually we want ring to fill as we approach fire time
    // Ring represents the lead window: alarmLeadMs total, msToAlarm remaining in that window
    const ringMs = alarmLeadMs; // total window shown in ring

    // Show overlay and play sound when alarm fires
    if (!alarmFired && msToAlarm <= 0 && msToTod > 0) {
        alarmFired = true;
        fireAlarm();
    }

    if (msToTod <= 0) {
        // T/D passed
        setAlarmBanner('idle', '🔕', 'T/D passed');
        $('countdown-time').textContent = '00:00';
        $('countdown-sub').textContent  = 'T/D reached';
        $('ring-fill').style.strokeDashoffset = RING_CIRC;
        return;
    }

    // Format time to T/D
    const totalSec = Math.ceil(msToTod / 1000);
    const hh = Math.floor(totalSec / 3600);
    const mm = Math.floor((totalSec % 3600) / 60);
    const ss = totalSec % 60;
    $('countdown-time').textContent = hh > 0
        ? `${hh}:${String(mm).padStart(2,'0')}:${String(ss).padStart(2,'0')}`
        : `${String(mm).padStart(2,'0')}:${String(ss).padStart(2,'0')}`;

    const ringFill = $('ring-fill');

    if (msToAlarm > 0) {
        // Counting down to alarm trigger point
        $('countdown-sub').textContent = 'to T/D';
        setAlarmBanner('armed', '🔔', `Alarm at ${fmtLead(alarmLeadMs)} before T/D`);
        // Ring shows progress through the total lead window
        // When msToAlarm = alarmLeadMs → ring empty (just armed)
        // When msToAlarm = 0           → ring full (alarm fires)
        const progress = 1 - (msToAlarm / ringMs);
        ringFill.style.strokeDashoffset = RING_CIRC * (1 - Math.min(progress, 1));
        ringFill.classList.remove('urgent','critical');
    } else {
        // Past alarm point — T/D imminent
        const secLeft = Math.ceil(msToTod/1000);
        $('countdown-sub').textContent  = '⚠ DESCEND NOW';
        setAlarmBanner('firing', '🚨', `T/D in ${secLeft}s`);
        ringFill.style.strokeDashoffset = 0;
        ringFill.classList.add('critical');
    }
}

function fmtLead(ms) {
    const m = Math.round(ms/60000);
    return m + ' min';
}

function setAlarmBanner(state, icon, text) {
    const el = $('alarm-banner');
    el.className = 'alarm-banner alarm-' + state;
    $('alarm-icon').textContent = icon;
    $('alarm-status-text').textContent = text;
}

function fireAlarm() {
    // Show overlay
    $('alarm-overlay').hidden = false;
    $('overlay-sub').textContent =
        (simbriefRoute?.dest?.icao ? `Descend for ${simbriefRoute.dest.icao}` : 'Descend now!');

    // Play sound — keep playing every 3s until dismissed
    playAlarmSound();
    const repeatTimer = setInterval(() => {
        if ($('alarm-overlay').hidden) { clearInterval(repeatTimer); return; }
        playAlarmSound();
    }, 3000);

    // Vibrate if mobile
    navigator.vibrate && navigator.vibrate([500,200,500,200,500]);
}

function setAlarm() {
    const h   = parseInt($('tod-hours').value) || 0;
    const m   = parseInt($('tod-mins').value)  || 0;
    const totalMs = (h*3600 + m*60) * 1000;

    if (totalMs <= 0) {
        alert('Please enter a time to T/D greater than 0.');
        return;
    }

    alarmDeadline = new Date(Date.now() + totalMs);
    alarmArmed    = true;
    alarmFired    = false;

    $('countdown-wrap').hidden    = false;
    $('btn-cancel-alarm').hidden  = false;
    $('btn-set-alarm').textContent = '🔔 Update';

    setAlarmBanner('armed', '🔔',
        `Alarm ${fmtLead(alarmLeadMs)} before T/D`);

    // Start tick
    clearInterval(alarmInterval);
    alarmInterval = setInterval(updateCountdownUI, 500);
    updateCountdownUI();
}

function cancelAlarm() {
    alarmArmed = false;
    alarmFired = false;
    alarmDeadline = null;
    clearInterval(alarmInterval);
    stopAlarmSound();
    $('alarm-overlay').hidden      = true;
    $('countdown-wrap').hidden     = true;
    $('btn-cancel-alarm').hidden   = true;
    $('btn-set-alarm').textContent = '🔔 Set Alarm';
    setAlarmBanner('idle','🔕','Alarm not set');
    $('ring-fill').style.strokeDashoffset = RING_CIRC;
    $('ring-fill').classList.remove('urgent','critical');
}

// ══════════════════════════════════════════════════════════════
// MAP  –  Leaflet setup
// ══════════════════════════════════════════════════════════════
const map = L.map('map', { center:[51.5,-0.1], zoom:12 });
const tiles = {
    osm: L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
        attribution:'© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',maxZoom:19}),
    sat: L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        {attribution:'© Esri',maxZoom:19})
};
tiles.osm.addTo(map);

// ══════════════════════════════════════════════════════════════
// APPLY STATE  –  map + sidebar + instruments
// ══════════════════════════════════════════════════════════════
function applyState(s) {
    // ── Aircraft marker ───────────────────────────────────────
    if (!acMarker) {
        acMarker = L.marker([s.lat,s.lon],{icon:makeAcIcon(s.heading),zIndexOffset:1000})
            .addTo(map)
            .bindPopup('<b>🐶 DogeTracker</b>');
    } else {
        acMarker.setLatLng([s.lat,s.lon]);
        acMarker.setIcon(makeAcIcon(s.heading));
    }

    // ── Trail ─────────────────────────────────────────────────
    if (showTrail) {
        trailPts.push([s.lat,s.lon]);
        if (trailPts.length > trailMax) trailPts.shift();
        const col = document.documentElement.dataset.theme==='dark' ? '#388bfd' : '#0969da';
        if (!trailLine) trailLine = L.polyline(trailPts,{color:col,weight:2,opacity:.6}).addTo(map);
        else { trailLine.setLatLngs(trailPts); trailLine.setStyle({color:col}); }
    }

    // ── Follow ────────────────────────────────────────────────
    if (followAc) map.setView([s.lat,s.lon],map.getZoom(),{animate:false});

    // ── T/D distance marker ───────────────────────────────────
    updateTodMarker(s);

    // ── Data fields ───────────────────────────────────────────
    $('val-lat').textContent = s.lat.toFixed(5)+'°';
    $('val-lon').textContent = s.lon.toFixed(5)+'°';
    $('val-hdg').textContent = Math.round(s.heading)+'°';
    $('val-alt').textContent = Math.round(s.altitude_ft).toLocaleString()+' ft';
    $('val-agl').textContent = Math.round(s.agl_ft).toLocaleString()+' ft';
    $('val-ias').textContent = Math.round(s.airspeed_kts)+' kts';
    $('val-gs').textContent  = Math.round(s.groundspeed_kts)+' kts';

    const vsEl = $('val-vs');
    const vsRnd = Math.round(s.vspeed_fpm);
    vsEl.textContent = (vsRnd>=0?'+':'')+vsRnd.toLocaleString()+' fpm';
    vsEl.className = 'val '+(vsRnd>100?'climb':vsRnd<-100?'descend':'level');

    $('val-wdir').textContent = Math.round(s.wind_dir)+'°';
    $('val-wspd').textContent = Math.round(s.wind_spd_kts)+' kts';

    // ── Instruments ───────────────────────────────────────────
    drawADI(s.pitch, s.roll);
    drawWindRose(s.wind_dir, s.wind_spd_kts, s.heading);
}

// ── T/D map marker ────────────────────────────────────────────
function updateTodMarker(s) {
    if (todMarker) { map.removeLayer(todMarker); todMarker=null; }
    if (!showTodMarker || !s || s.altitude_ft < 100) return;
    const dist = todDistNM(s.altitude_ft, todAngle);
    let brg = s.heading;
    if (simbriefRoute?.dest) brg = bearing(s.lat,s.lon,simbriefRoute.dest.lat,simbriefRoute.dest.lon);
    const [tlat,tlon] = destination(s.lat,s.lon,dist,brg);
    todMarker = L.marker([tlat,tlon],{
        icon:L.divIcon({html:`<div class="tod-marker-icon">T/D&thinsp;${dist.toFixed(1)}&thinsp;NM</div>`,
                        className:'',iconAnchor:[0,10]}),
        zIndexOffset:900
    }).addTo(map);
    $('tod-dist').textContent = dist.toFixed(1)+' NM';
    $('tod-brg').textContent  = Math.round(brg)+'°';
}

// ══════════════════════════════════════════════════════════════
// ADI CANVAS
// ══════════════════════════════════════════════════════════════
const adiCanvas = $('adi-canvas');
const adiCtx    = adiCanvas.getContext('2d');
const ADI_R=80, ADI_CX=100, ADI_CY=100;

function drawADI(pitch,roll) {
    const W=adiCanvas.width, H=adiCanvas.height;
    adiCtx.clearRect(0,0,W,H);
    adiCtx.save();
    adiCtx.beginPath();
    adiCtx.arc(ADI_CX,ADI_CY,ADI_R,0,Math.PI*2);
    adiCtx.clip();
    adiCtx.save();
    adiCtx.translate(ADI_CX,ADI_CY);
    adiCtx.rotate(toRad(-roll));
    const pitchPx = clamp(pitch*2.5,-ADI_R,ADI_R);
    adiCtx.fillStyle='#1a6ca8'; adiCtx.fillRect(-ADI_R,-ADI_R*2,ADI_R*2,ADI_R*2+pitchPx);
    adiCtx.fillStyle='#8b5e3c'; adiCtx.fillRect(-ADI_R,pitchPx,ADI_R*2,ADI_R*2);
    adiCtx.strokeStyle='#fff'; adiCtx.lineWidth=2;
    adiCtx.beginPath(); adiCtx.moveTo(-ADI_R,pitchPx); adiCtx.lineTo(ADI_R,pitchPx); adiCtx.stroke();
    adiCtx.strokeStyle='rgba(255,255,255,.6)'; adiCtx.lineWidth=1; adiCtx.font='9px monospace';
    adiCtx.textAlign='right'; adiCtx.fillStyle='rgba(255,255,255,.6)';
    for(let p=-20;p<=20;p+=5){
        if(p===0)continue;
        const py=pitchPx-p*2.5, w=p%10===0?28:16;
        adiCtx.beginPath(); adiCtx.moveTo(-w,py); adiCtx.lineTo(w,py); adiCtx.stroke();
        if(p%10===0) adiCtx.fillText(Math.abs(p),-w-3,py+3);
    }
    adiCtx.restore();
    // Fixed reference
    adiCtx.strokeStyle='#ffd700'; adiCtx.lineWidth=2.5;
    adiCtx.beginPath();
    adiCtx.moveTo(ADI_CX-38,ADI_CY); adiCtx.lineTo(ADI_CX-15,ADI_CY);
    adiCtx.lineTo(ADI_CX-15,ADI_CY+6);
    adiCtx.moveTo(ADI_CX+38,ADI_CY); adiCtx.lineTo(ADI_CX+15,ADI_CY);
    adiCtx.lineTo(ADI_CX+15,ADI_CY+6);
    adiCtx.arc(ADI_CX,ADI_CY,3,0,Math.PI*2);
    adiCtx.stroke();
    // Bank arc
    adiCtx.strokeStyle='rgba(255,255,255,.4)'; adiCtx.lineWidth=1;
    for(const a of[-60,-45,-30,-20,-10,0,10,20,30,45,60]){
        const ar=toRad(a-90), r1=ADI_R-5, r2=ADI_R-(a%30===0?14:9);
        adiCtx.beginPath();
        adiCtx.moveTo(ADI_CX+r1*Math.cos(ar),ADI_CY+r1*Math.sin(ar));
        adiCtx.lineTo(ADI_CX+r2*Math.cos(ar),ADI_CY+r2*Math.sin(ar));
        adiCtx.stroke();
    }
    // Bank pointer
    adiCtx.save(); adiCtx.translate(ADI_CX,ADI_CY); adiCtx.rotate(toRad(-roll));
    adiCtx.fillStyle='#ffd700'; adiCtx.beginPath();
    adiCtx.moveTo(0,-(ADI_R-16)); adiCtx.lineTo(-5,-(ADI_R-8)); adiCtx.lineTo(5,-(ADI_R-8));
    adiCtx.closePath(); adiCtx.fill(); adiCtx.restore();
    // Border
    adiCtx.beginPath(); adiCtx.arc(ADI_CX,ADI_CY,ADI_R,0,Math.PI*2);
    adiCtx.strokeStyle='rgba(255,255,255,.25)'; adiCtx.lineWidth=1.5; adiCtx.stroke();
    adiCtx.restore();
    $('adi-pitch').textContent='P: '+pitch.toFixed(1)+'°';
    $('adi-roll').textContent ='R: '+roll.toFixed(1)+'°';
}

// ══════════════════════════════════════════════════════════════
// WIND ROSE CANVAS
// ══════════════════════════════════════════════════════════════
const windCanvas=$('wind-canvas'), windCtx=windCanvas.getContext('2d');

function drawWindRose(windDir,windSpd,acHdg) {
    const W=windCanvas.width,H=windCanvas.height,cx=W/2,cy=H/2,R=30;
    windCtx.clearRect(0,0,W,H);
    const dark=document.documentElement.dataset.theme==='dark';
    const fg=dark?'#8b949e':'#57606a', arrow='#58a6ff';
    windCtx.beginPath(); windCtx.arc(cx,cy,R,0,Math.PI*2);
    windCtx.strokeStyle=fg; windCtx.lineWidth=1; windCtx.stroke();
    windCtx.fillStyle=fg; windCtx.font='bold 8px sans-serif';
    windCtx.textAlign='center'; windCtx.textBaseline='middle';
    windCtx.fillText('N',cx,cy-R+6); windCtx.fillText('S',cx,cy+R-6);
    windCtx.fillText('W',cx-R+6,cy); windCtx.fillText('E',cx+R-6,cy);
    const wr=toRad(windDir-90), len=clamp(windSpd/3,8,R-4);
    const tx=cx+Math.cos(wr)*len, ty=cy+Math.sin(wr)*len;
    windCtx.strokeStyle=arrow; windCtx.lineWidth=2;
    windCtx.beginPath(); windCtx.moveTo(cx,cy); windCtx.lineTo(tx,ty); windCtx.stroke();
    const ah=Math.atan2(ty-cy,tx-cx);
    windCtx.fillStyle=arrow; windCtx.beginPath();
    windCtx.moveTo(tx,ty);
    windCtx.lineTo(tx-6*Math.cos(ah-.4),ty-6*Math.sin(ah-.4));
    windCtx.lineTo(tx-6*Math.cos(ah+.4),ty-6*Math.sin(ah+.4));
    windCtx.closePath(); windCtx.fill();
    windCtx.fillStyle=fg; windCtx.font='8px sans-serif';
    windCtx.textBaseline='bottom'; windCtx.fillText(Math.round(windSpd)+'kt',cx,H-1);
}

// ══════════════════════════════════════════════════════════════
// LERP ANIMATION
// ══════════════════════════════════════════════════════════════
function startLerp(from,to){
    if(rafId)cancelAnimationFrame(rafId);
    lerpFrom=from; lerpTarget=to; lerpFrame=0;
    function tick(){
        lerpFrame++;
        const t=Math.min(lerpFrame/LERP_FPS,1);
        applyState(lerpState(lerpFrom,lerpTarget,t));
        if(t<1) rafId=requestAnimationFrame(tick);
        else    currentPos=to;
    }
    rafId=requestAnimationFrame(tick);
}

// ══════════════════════════════════════════════════════════════
// POLL LOOP
// ══════════════════════════════════════════════════════════════
function setConnected(ok){
    $('conn-dot').className   ='dot '+(ok?'dot-ok':'dot-bad');
    $('conn-label').textContent=ok?'Connected':'Disconnected';
}

async function poll(){
    try{
        const r=await fetch(`http://127.0.0.1:${PORT}/api/position`,{cache:'no-store'});
        if(!r.ok)throw new Error('HTTP '+r.status);
        const d=await r.json();
        setConnected(true);
        $('last-update').textContent=new Date().toLocaleTimeString();
        if(!currentPos){currentPos=d;applyState(d);map.setView([d.lat,d.lon],map.getZoom());}
        else if(smoothLerp) startLerp(currentPos,d);
        else{currentPos=d;applyState(d);}
    }catch{setConnected(false);}
    setTimeout(poll,POLL_MS);
}

// ══════════════════════════════════════════════════════════════
// PHASE 3  –  SIMBRIEF  (enhanced with fuel, aircraft type,
//              full fix count, better route display)
// ══════════════════════════════════════════════════════════════
async function loadSimbrief(pilotId){
    const st=$('sb-status');
    st.className='status-msg'; st.textContent='Loading from SimBrief…';
    clearRoute();

    try{
        const url=`https://www.simbrief.com/api/xml.fetcher.php?username=${encodeURIComponent(pilotId)}&json=1`;
        const r=await fetch(url);
        if(!r.ok)throw new Error('HTTP '+r.status);
        const d=await r.json();
        if(d.fetch?.status==='Error')throw new Error(d.fetch.message||'SimBrief error');

        // ── Parse all data ────────────────────────────────────
        const fixes=(d.navlog?.fix??[]).filter(f=>f.pos_lat!=null&&f.pos_long!=null)
            .map(f=>({ident:f.ident||'?',lat:+f.pos_lat,lon:+f.pos_long,altFt:+(f.altitude_feet||0),
                      type:f.type||'wpt'}));

        if(fixes.length<2)throw new Error('No waypoints in flight plan');

        const orig    = d.origin?.icao_code      || '----';
        const dest    = d.destination?.icao_code || '----';
        const actype  = d.aircraft?.icaocode      || d.aircraft?.name || '--';
        const fl      = d.general?.cruise_altitude|| '--';
        const distNMt = d.general?.route_distance  || '--';
        const fuel    = d.fuel?.plan_ramp          || '--';
        const rte     = d.general?.route_ifps      || '';

        simbriefRoute = {
            waypoints: fixes,
            dest: {
                icao: dest,
                lat:  +d.destination.pos_lat,
                lon:  +d.destination.pos_long
            }
        };

        drawRoute(fixes, orig, dest);

        st.className='status-msg ok';
        st.textContent=`✔ ${fixes.length} fixes  ·  ${orig} → ${dest}`;
        $('fi-od').textContent     = `${orig} → ${dest}`;
        $('fi-actype').textContent = actype;
        $('fi-cruise').textContent = `FL${fl}`;
        $('fi-dist').textContent   = distNMt !== '--' ? distNMt+' NM' : '--';
        $('fi-fuel').textContent   = fuel !== '--' ? (+fuel).toLocaleString()+' kg' : '--';
        $('fi-fixes').textContent  = fixes.length+' waypoints';
        $('fi-route').textContent  = rte || 'DCT';
        $('sb-info').hidden=false;

    }catch(e){
        st.className='status-msg err';
        st.textContent='✖ '+e.message;
        console.error('[SimBrief]',e);
    }
}

function drawRoute(fixes, orig, dest){
    if(routeLayer){map.removeLayer(routeLayer);routeLayer=null;}
    routeLayer=L.layerGroup();

    // Main route polyline
    const coords=fixes.map(f=>[f.lat,f.lon]);
    L.polyline(coords,{color:'#ff9800',weight:2.5,opacity:.85,dashArray:'6 4'}).addTo(routeLayer);

    // Waypoints — every Nth gets a label to avoid clutter
    const step=Math.max(1,Math.floor(fixes.length/18));
    fixes.forEach((f,i)=>{
        const isEnd = i===0||i===fixes.length-1;
        const col   = isEnd?'#f85149':'#ff9800';
        const r     = isEnd?7:3;

        L.circleMarker([f.lat,f.lon],{radius:r,color:col,fillColor:col,fillOpacity:.95,weight:1.2})
         .bindPopup(
            `<b>${f.ident}</b><br>`+
            `${f.lat.toFixed(4)}°, ${f.lon.toFixed(4)}°`+
            (f.altFt?`<br>Alt: ${f.altFt.toLocaleString()} ft`:'')
         ).addTo(routeLayer);

        if(isEnd||i%step===0){
            L.marker([f.lat,f.lon],{
                icon:L.divIcon({html:`<div class="wp-label">${f.ident}</div>`,className:'',iconAnchor:[-4,8]}),
                interactive:false,zIndexOffset:500
            }).addTo(routeLayer);
        }
    });

    routeLayer.addTo(map);
    map.fitBounds(L.latLngBounds(coords),{padding:[40,40]});
}

function clearRoute(){
    if(routeLayer){map.removeLayer(routeLayer);routeLayer=null;}
    simbriefRoute=null;
    $('sb-info').hidden=true;
    $('sb-status').className='status-msg';
    $('sb-status').textContent='';
}

// ══════════════════════════════════════════════════════════════
// THEME
// ══════════════════════════════════════════════════════════════
function applyTheme(t){
    document.documentElement.dataset.theme=t;
    $('themeToggle').querySelector('.theme-icon').textContent=t==='dark'?'☀':'☾';
    localStorage.setItem('doge-theme',t);
    if(trailLine) trailLine.setStyle({color:t==='dark'?'#388bfd':'#0969da'});
    if(currentPos) drawWindRose(currentPos.wind_dir,currentPos.wind_spd_kts,currentPos.heading);
}

// ══════════════════════════════════════════════════════════════
// EVENT WIRING
// ══════════════════════════════════════════════════════════════
$('themeToggle').addEventListener('click',()=>
    applyTheme(document.documentElement.dataset.theme==='dark'?'light':'dark'));

$('opt-follow').addEventListener('change',e=>{
    followAc=e.target.checked;
    if(followAc&&currentPos)map.setView([currentPos.lat,currentPos.lon],map.getZoom());
});
$('opt-trail').addEventListener('change',e=>{
    showTrail=e.target.checked;
    if(!showTrail&&trailLine){map.removeLayer(trailLine);trailLine=null;trailPts=[];}
});
$('opt-satellite').addEventListener('change',e=>{
    if(e.target.checked){map.removeLayer(tiles.osm);tiles.sat.addTo(map);}
    else{map.removeLayer(tiles.sat);tiles.osm.addTo(map);}
});
$('opt-smooth').addEventListener('change',e=>smoothLerp=e.target.checked);

$('zoom-slider').addEventListener('input',e=>{
    const z=+e.target.value;$('zoom-val').textContent=z;map.setZoom(z);});
map.on('zoom',()=>{const z=map.getZoom();$('zoom-slider').value=z;$('zoom-val').textContent=z;});
$('trail-slider').addEventListener('input',e=>{
    trailMax=+e.target.value;$('trail-val').textContent=trailMax;
    while(trailPts.length>trailMax)trailPts.shift();
    if(trailLine)trailLine.setLatLngs(trailPts);
});
map.on('dragstart',()=>{followAc=false;$('opt-follow').checked=false;});
$('btn-center').addEventListener('click',()=>{
    if(currentPos){followAc=true;$('opt-follow').checked=true;
        map.setView([currentPos.lat,currentPos.lon],map.getZoom(),{animate:true});}
});

// SimBrief
$('btn-load-route').addEventListener('click',()=>{
    const id=$('sb-id').value.trim();
    if(!id){$('sb-status').className='status-msg err';
             $('sb-status').textContent='Enter your SimBrief Pilot ID or Username';return;}
    loadSimbrief(id);
});
$('sb-id').addEventListener('keydown',e=>{if(e.key==='Enter')$('btn-load-route').click();});
$('btn-clear-route').addEventListener('click',clearRoute);

// T/D Alarm
$('btn-set-alarm').addEventListener('click',setAlarm);
$('btn-cancel-alarm').addEventListener('click',cancelAlarm);
$('btn-dismiss-alarm').addEventListener('click',()=>{
    $('alarm-overlay').hidden=true;
    stopAlarmSound();
    // Keep alarm armed for continued countdown display
    setAlarmBanner('firing','🚨','T/D — descend!');
});
$('btn-test-alarm').addEventListener('click',()=>{
    // Unlock audio context by user gesture, then test
    getAudioCtx().resume().then(()=>playAlarmSound());
});

$('alarm-lead').addEventListener('input',e=>{
    alarmLeadMs=+e.target.value*60000;
    $('alarm-lead-val').textContent=e.target.value;
});
$('alarm-vol').addEventListener('input',e=>{
    alarmVolume=+e.target.value/100;
    $('alarm-vol-val').textContent=e.target.value+'%';
});
document.querySelectorAll('input[name="alarm-sound"]')
    .forEach(r=>r.addEventListener('change',e=>alarmSound=e.target.value));

// T/D map marker
$('opt-tod').addEventListener('change',e=>{
    showTodMarker=e.target.checked;
    if(!showTodMarker&&todMarker){map.removeLayer(todMarker);todMarker=null;}
    if(showTodMarker&&currentPos)updateTodMarker(currentPos);
});
$('tod-angle').addEventListener('input',e=>{
    todAngle=+e.target.value;$('tod-angle-val').textContent=todAngle+'°';
    if(currentPos)updateTodMarker(currentPos);
});

// Persist SimBrief ID
$('sb-id').addEventListener('input',e=>localStorage.setItem('doge-sbid',e.target.value.trim()));

// ══════════════════════════════════════════════════════════════
// BOOT
// ══════════════════════════════════════════════════════════════
(function init(){
    applyTheme(localStorage.getItem('doge-theme')||'dark');
    const sid=localStorage.getItem('doge-sbid');
    if(sid)$('sb-id').value=sid;
    drawADI(0,0);
    drawWindRose(0,0,0);
    setConnected(false);
    poll();
})();
