// ============================================================
// DogeTracker  –  script.js
//
// Phase 1: Live lat/lon, map, 1-second poll
// Phase 2: Heading rotation, smooth lerp, pitch/roll ADI,
//          wind rose, IAS/VS/AGL display, VS colour coding,
//          variable trail length, interpolation toggle
// Phase 3: SimBrief route + waypoints
// Phase 5: Top of Descent marker
// ============================================================

'use strict';

// ── Constants ────────────────────────────────────────────────
const POLL_MS      = 1000;   // server poll interval
const LERP_FPS     = 60;     // animation frames per poll cycle
const PORT         = 4000;   // must match plugin.cpp

// ── State ────────────────────────────────────────────────────
let currentPos     = null;   // last fully-applied AircraftState
let lerpFrom       = null;   // lerp start snapshot
let lerpTarget     = null;   // lerp end snapshot
let lerpFrame      = 0;
let rafId          = null;

let trailPts       = [];
let trailMax       = 300;    // controlled by slider
let trailLine      = null;

let acMarker       = null;
let todMarker      = null;
let routeLayer     = null;
let simbriefRoute  = null;

let followAc       = true;
let showTrail      = true;
let smoothLerp     = true;
let showTod        = true;
let todAngle       = 3.0;    // descent angle degrees

// ── Maths helpers ────────────────────────────────────────────
const lerp     = (a,b,t)    => a + (b-a)*t;
const clamp    = (v,lo,hi)  => Math.max(lo, Math.min(hi, v));
const toRad    = d           => d * Math.PI/180;
const toDeg    = r           => r * 180/Math.PI;

function lerpHeading(a, b, t) {
    let d = ((b - a) + 540) % 360 - 180;
    return (a + d * t + 360) % 360;
}

function lerpState(a, b, t) {
    return {
        lat:             lerp(a.lat,             b.lat,             t),
        lon:             lerp(a.lon,             b.lon,             t),
        heading:         lerpHeading(a.heading,  b.heading,         t),
        pitch:           lerp(a.pitch,           b.pitch,           t),
        roll:            lerp(a.roll,            b.roll,            t),
        altitude_ft:     lerp(a.altitude_ft,     b.altitude_ft,     t),
        agl_ft:          lerp(a.agl_ft,          b.agl_ft,          t),
        groundspeed_kts: lerp(a.groundspeed_kts, b.groundspeed_kts, t),
        airspeed_kts:    lerp(a.airspeed_kts,    b.airspeed_kts,    t),
        vspeed_fpm:      lerp(a.vspeed_fpm,      b.vspeed_fpm,      t),
        wind_dir:        lerp(a.wind_dir,        b.wind_dir,        t),
        wind_spd_kts:    lerp(a.wind_spd_kts,    b.wind_spd_kts,    t),
    };
}

// Great-circle distance in NM
function distNM(lat1,lon1,lat2,lon2) {
    const R=3440.065,dL=toRad(lat2-lat1),dG=toRad(lon2-lon1);
    const a=Math.sin(dL/2)**2+Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dG/2)**2;
    return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
}

// Bearing A→B in degrees
function bearing(lat1,lon1,lat2,lon2) {
    const dG=toRad(lon2-lon1);
    const y=Math.sin(dG)*Math.cos(toRad(lat2));
    const x=Math.cos(toRad(lat1))*Math.sin(toRad(lat2))-Math.sin(toRad(lat1))*Math.cos(toRad(lat2))*Math.cos(dG);
    return (toDeg(Math.atan2(y,x))+360)%360;
}

// Destination point given distance (NM) + bearing
function destination(lat,lon,dist,brg) {
    const d=dist/3440.065, bR=toRad(brg), pR=toRad(lat);
    const nLat=Math.asin(Math.sin(pR)*Math.cos(d)+Math.cos(pR)*Math.sin(d)*Math.cos(bR));
    const nLon=toRad(lon)+Math.atan2(Math.sin(bR)*Math.sin(d)*Math.cos(pR),Math.cos(d)-Math.sin(pR)*Math.sin(nLat));
    return [toDeg(nLat), toDeg(nLon)];
}

// T/D distance in NM: alt_ft / (tan(angle) * 6076.12)
function todDistNM(altFt, angleDeg) {
    return altFt / (Math.tan(toRad(angleDeg)) * 6076.12);
}

// ── Aircraft SVG icon (Doge-themed blue plane) ────────────────
function makeAcIcon(hdg) {
    const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40">
      <g transform="rotate(${hdg},20,20)">
        <!-- Shadow -->
        <path d="M20 4 L24 18 L38 22 L24 24 L22 36 L20 32 L18 36 L16 24 L2 22 L16 18 Z"
              fill="rgba(0,0,0,0.25)" transform="translate(1,1)"/>
        <!-- Body -->
        <path d="M20 4 L24 18 L38 22 L24 24 L22 36 L20 32 L18 36 L16 24 L2 22 L16 18 Z"
              fill="#388bfd" stroke="#1158c7" stroke-width="1.2" stroke-linejoin="round"/>
        <!-- Cockpit highlight -->
        <ellipse cx="20" cy="10" rx="2.5" ry="3.5" fill="rgba(255,255,255,0.35)"/>
        <!-- Doge nose dot -->
        <circle cx="20" cy="5.5" r="1.2" fill="#ffd700"/>
      </g>
    </svg>`;
    return L.divIcon({
        html:        `<div class="ac-icon-outer">${svg}</div>`,
        className:   '',
        iconSize:    [40,40],
        iconAnchor:  [20,20],
        popupAnchor: [0,-24]
    });
}

// ── Leaflet map ───────────────────────────────────────────────
const map = L.map('map', { center:[51.5,-0.1], zoom:12, zoomControl:true });

const tileLayers = {
    osm: L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution:'© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
        maxZoom:19
    }),
    sat: L.tileLayer(
        'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        { attribution:'© Esri, Maxar', maxZoom:19 }
    )
};
tileLayers.osm.addTo(map);

// ── Apply a fully-resolved state to the map + UI ──────────────
function applyState(s) {
    // ── Aircraft marker ───────────────────────────────────────
    if (!acMarker) {
        acMarker = L.marker([s.lat, s.lon], { icon:makeAcIcon(s.heading), zIndexOffset:1000 })
            .addTo(map)
            .bindPopup(`<b>🐶 DogeTracker</b><br>Your aircraft`);
    } else {
        acMarker.setLatLng([s.lat, s.lon]);
        acMarker.setIcon(makeAcIcon(s.heading));
    }

    // ── Trail ─────────────────────────────────────────────────
    if (showTrail) {
        trailPts.push([s.lat, s.lon]);
        if (trailPts.length > trailMax) trailPts.shift();
        const theme = document.documentElement.dataset.theme;
        const col   = theme === 'dark' ? '#388bfd' : '#0969da';
        if (!trailLine) {
            trailLine = L.polyline(trailPts, { color:col, weight:2, opacity:0.6 }).addTo(map);
        } else {
            trailLine.setLatLngs(trailPts);
            trailLine.setStyle({ color:col });
        }
    }

    // ── Follow ────────────────────────────────────────────────
    if (followAc) map.setView([s.lat, s.lon], map.getZoom(), { animate:false });

    // ── ToD marker ────────────────────────────────────────────
    updateTod(s);

    // ── Sidebar data fields ───────────────────────────────────
    $('val-lat').textContent  = s.lat.toFixed(5) + '°';
    $('val-lon').textContent  = s.lon.toFixed(5) + '°';
    $('val-hdg').textContent  = Math.round(s.heading) + '°';
    $('val-alt').textContent  = Math.round(s.altitude_ft).toLocaleString() + ' ft';
    $('val-agl').textContent  = Math.round(s.agl_ft).toLocaleString() + ' ft';
    $('val-ias').textContent  = Math.round(s.airspeed_kts) + ' kts';
    $('val-gs').textContent   = Math.round(s.groundspeed_kts) + ' kts';

    // V/S with colour coding
    const vsEl = $('val-vs');
    const vsRnd = Math.round(s.vspeed_fpm);
    vsEl.textContent = (vsRnd >= 0 ? '+' : '') + vsRnd.toLocaleString() + ' fpm';
    vsEl.className   = 'val ' + (vsRnd > 100 ? 'climb' : vsRnd < -100 ? 'descend' : 'level');

    // Wind
    $('val-wdir').textContent = Math.round(s.wind_dir) + '°';
    $('val-wspd').textContent = Math.round(s.wind_spd_kts) + ' kts';

    // ── Phase 2 instruments ───────────────────────────────────
    drawADI(s.pitch, s.roll);
    drawWindRose(s.wind_dir, s.wind_spd_kts, s.heading);
}

// ── ADI canvas ────────────────────────────────────────────────
const adiCanvas = document.getElementById('adi-canvas');
const adiCtx    = adiCanvas.getContext('2d');
const ADI_R     = 80;   // radius in canvas units (canvas is 200×200)
const ADI_CX    = 100;
const ADI_CY    = 100;

function drawADI(pitchDeg, rollDeg) {
    const W = adiCanvas.width, H = adiCanvas.height;
    adiCtx.clearRect(0, 0, W, H);

    adiCtx.save();
    // Clip to circle
    adiCtx.beginPath();
    adiCtx.arc(ADI_CX, ADI_CY, ADI_R, 0, Math.PI*2);
    adiCtx.clip();

    // ── Sky/ground split, rotated by roll, shifted by pitch ──
    adiCtx.save();
    adiCtx.translate(ADI_CX, ADI_CY);
    adiCtx.rotate(toRad(-rollDeg));

    const pitchPx = clamp(pitchDeg * 2.5, -ADI_R, ADI_R);

    // Sky
    adiCtx.fillStyle = '#1a6ca8';
    adiCtx.fillRect(-ADI_R, -ADI_R*2, ADI_R*2, ADI_R*2 + pitchPx);
    // Ground
    adiCtx.fillStyle = '#8b5e3c';
    adiCtx.fillRect(-ADI_R, pitchPx, ADI_R*2, ADI_R*2);
    // Horizon line
    adiCtx.strokeStyle = '#fff';
    adiCtx.lineWidth   = 2;
    adiCtx.beginPath();
    adiCtx.moveTo(-ADI_R, pitchPx);
    adiCtx.lineTo( ADI_R, pitchPx);
    adiCtx.stroke();

    // Pitch ladder (every 5°)
    adiCtx.strokeStyle = 'rgba(255,255,255,0.7)';
    adiCtx.fillStyle   = 'rgba(255,255,255,0.7)';
    adiCtx.lineWidth   = 1;
    adiCtx.font        = '9px monospace';
    adiCtx.textAlign   = 'right';
    for (let p = -20; p <= 20; p += 5) {
        if (p === 0) continue;
        const py = pitchPx - p * 2.5;
        const w  = (p % 10 === 0) ? 28 : 16;
        adiCtx.beginPath();
        adiCtx.moveTo(-w, py); adiCtx.lineTo(w, py);
        adiCtx.stroke();
        if (p % 10 === 0) {
            adiCtx.fillText(Math.abs(p), -w - 3, py + 3);
        }
    }

    adiCtx.restore();

    // ── Fixed aircraft reference symbol ───────────────────────
    adiCtx.strokeStyle = '#ffd700';
    adiCtx.lineWidth   = 2.5;
    adiCtx.beginPath();
    // Left wing
    adiCtx.moveTo(ADI_CX - 38, ADI_CY); adiCtx.lineTo(ADI_CX - 15, ADI_CY);
    adiCtx.lineTo(ADI_CX - 15, ADI_CY + 6);
    // Right wing
    adiCtx.moveTo(ADI_CX + 38, ADI_CY); adiCtx.lineTo(ADI_CX + 15, ADI_CY);
    adiCtx.lineTo(ADI_CX + 15, ADI_CY + 6);
    // Centre dot
    adiCtx.moveTo(ADI_CX,    ADI_CY);
    adiCtx.arc(ADI_CX, ADI_CY, 3, 0, Math.PI*2);
    adiCtx.stroke();

    // ── Roll arc at top ───────────────────────────────────────
    adiCtx.strokeStyle = 'rgba(255,255,255,0.5)';
    adiCtx.lineWidth   = 1;
    for (const ang of [-60,-45,-30,-20,-10,0,10,20,30,45,60]) {
        const a = toRad(ang - 90);
        const r1 = ADI_R - 5, r2 = ADI_R - (ang % 30 === 0 ? 14 : 9);
        adiCtx.beginPath();
        adiCtx.moveTo(ADI_CX + r1*Math.cos(a), ADI_CY + r1*Math.sin(a));
        adiCtx.lineTo(ADI_CX + r2*Math.cos(a), ADI_CY + r2*Math.sin(a));
        adiCtx.stroke();
    }
    // Bank pointer
    adiCtx.save();
    adiCtx.translate(ADI_CX, ADI_CY);
    adiCtx.rotate(toRad(-rollDeg));
    adiCtx.fillStyle = '#ffd700';
    adiCtx.beginPath();
    adiCtx.moveTo(0, -(ADI_R - 16));
    adiCtx.lineTo(-5, -(ADI_R - 8));
    adiCtx.lineTo( 5, -(ADI_R - 8));
    adiCtx.closePath();
    adiCtx.fill();
    adiCtx.restore();

    // ── Border ────────────────────────────────────────────────
    adiCtx.beginPath();
    adiCtx.arc(ADI_CX, ADI_CY, ADI_R, 0, Math.PI*2);
    adiCtx.strokeStyle = 'rgba(255,255,255,0.3)';
    adiCtx.lineWidth   = 1.5;
    adiCtx.stroke();

    adiCtx.restore();

    // Labels
    $('adi-pitch').textContent = 'P: ' + pitchDeg.toFixed(1) + '°';
    $('adi-roll').textContent  = 'R: ' + rollDeg.toFixed(1)  + '°';
}

// ── Wind rose canvas ──────────────────────────────────────────
const windCanvas = document.getElementById('wind-canvas');
const windCtx    = windCanvas.getContext('2d');

function drawWindRose(windDir, windSpd, acHdg) {
    const W = windCanvas.width, H = windCanvas.height;
    const cx = W/2, cy = H/2, R = 30;
    windCtx.clearRect(0, 0, W, H);

    const theme = document.documentElement.dataset.theme;
    const fg    = theme === 'dark' ? '#8b949e' : '#57606a';
    const arrow = '#58a6ff';

    // Background circle
    windCtx.beginPath();
    windCtx.arc(cx, cy, R, 0, Math.PI*2);
    windCtx.strokeStyle = fg;
    windCtx.lineWidth   = 1;
    windCtx.stroke();

    // Cardinal letters  (N always at top of canvas, not relative to heading)
    windCtx.fillStyle = fg;
    windCtx.font      = 'bold 8px sans-serif';
    windCtx.textAlign = 'center';
    windCtx.textBaseline = 'middle';
    windCtx.fillText('N', cx,    cy - R + 6);
    windCtx.fillText('S', cx,    cy + R - 6);
    windCtx.fillText('W', cx - R + 6, cy);
    windCtx.fillText('E', cx + R - 6, cy);

    // Wind arrow (FROM direction, so arrow tip points in the wind direction)
    const windRad = toRad(windDir - 90);
    const len     = clamp(windSpd / 3, 8, R - 4);
    const tx = cx + Math.cos(windRad) * len;
    const ty = cy + Math.sin(windRad) * len;

    windCtx.strokeStyle = arrow;
    windCtx.lineWidth   = 2;
    windCtx.beginPath();
    windCtx.moveTo(cx, cy);
    windCtx.lineTo(tx, ty);
    windCtx.stroke();
    // Arrowhead
    const ahAngle = Math.atan2(ty - cy, tx - cx);
    windCtx.fillStyle = arrow;
    windCtx.beginPath();
    windCtx.moveTo(tx, ty);
    windCtx.lineTo(tx - 6*Math.cos(ahAngle-0.4), ty - 6*Math.sin(ahAngle-0.4));
    windCtx.lineTo(tx - 6*Math.cos(ahAngle+0.4), ty - 6*Math.sin(ahAngle+0.4));
    windCtx.closePath();
    windCtx.fill();

    // Speed label
    windCtx.fillStyle    = fg;
    windCtx.font         = '8px sans-serif';
    windCtx.textAlign    = 'center';
    windCtx.textBaseline = 'bottom';
    windCtx.fillText(Math.round(windSpd) + 'kt', cx, H - 1);
}

// ── ToD marker ────────────────────────────────────────────────
function updateTod(s) {
    if (todMarker) { map.removeLayer(todMarker); todMarker = null; }
    if (!showTod || !s || s.altitude_ft < 100) return;

    const dist = todDistNM(s.altitude_ft, todAngle);
    let brg = s.heading;
    if (simbriefRoute?.dest)
        brg = bearing(s.lat, s.lon, simbriefRoute.dest.lat, simbriefRoute.dest.lon);

    const [tlat, tlon] = destination(s.lat, s.lon, dist, brg);
    const icon = L.divIcon({
        html:      `<div class="tod-marker-icon">T/D&thinsp;${dist.toFixed(1)}&thinsp;NM</div>`,
        className: '', iconAnchor:[0,10]
    });
    todMarker = L.marker([tlat, tlon], { icon, zIndexOffset:900 }).addTo(map);
    $('tod-dist').textContent = dist.toFixed(1) + ' NM';
    $('tod-brg').textContent  = Math.round(brg) + '°';
}

// ── Lerp animation loop ───────────────────────────────────────
function startLerp(from, to) {
    if (rafId) cancelAnimationFrame(rafId);
    lerpFrom   = from;
    lerpTarget = to;
    lerpFrame  = 0;

    function tick() {
        lerpFrame++;
        const t = Math.min(lerpFrame / LERP_FPS, 1);
        const s = lerpState(lerpFrom, lerpTarget, t);
        applyState(s);
        if (t < 1) rafId = requestAnimationFrame(tick);
        else       currentPos = to;
    }
    rafId = requestAnimationFrame(tick);
}

// ── Connection status ─────────────────────────────────────────
function setConnected(ok) {
    $('conn-dot').className    = 'dot ' + (ok ? 'dot-ok' : 'dot-bad');
    $('conn-label').textContent = ok ? 'Connected' : 'Disconnected';
}

// ── Poll loop ─────────────────────────────────────────────────
async function poll() {
    try {
        const res  = await fetch(`http://127.0.0.1:${PORT}/api/position`, { cache:'no-store' });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const data = await res.json();

        setConnected(true);
        $('last-update').textContent = new Date().toLocaleTimeString();

        if (!currentPos) {
            currentPos = data;
            applyState(data);
            map.setView([data.lat, data.lon], map.getZoom());
        } else if (smoothLerp) {
            startLerp(currentPos, data);
        } else {
            currentPos = data;
            applyState(data);
        }
    } catch(e) {
        setConnected(false);
    }
    setTimeout(poll, POLL_MS);
}

// ── SimBrief ──────────────────────────────────────────────────
async function loadSimbrief(pilotId) {
    const st = $('sb-status');
    st.className = 'status-msg'; st.textContent = 'Loading…';
    clearRoute();

    try {
        const url = `https://www.simbrief.com/api/xml.fetcher.php?username=${encodeURIComponent(pilotId)}&json=1`;
        const res  = await fetch(url);
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const data = await res.json();
        if (data.fetch?.status === 'Error') throw new Error(data.fetch.message || 'SimBrief error');

        const fixes = data.navlog?.fix ?? [];
        const wps = fixes
            .filter(f => f.pos_lat != null && f.pos_long != null)
            .map(f => ({ ident:f.ident||'?', lat:+f.pos_lat, lon:+f.pos_long, altFt:+(f.altitude_feet||0) }));
        if (wps.length < 2) throw new Error('No waypoints in plan');

        const orig = data.origin?.icao_code || '----';
        const dest = data.destination?.icao_code || '----';
        const fl   = data.general?.cruise_altitude || '--';
        const rte  = data.general?.route_ifps || '';

        simbriefRoute = {
            waypoints: wps,
            dest: { lat:+data.destination.pos_lat, lon:+data.destination.pos_long }
        };
        drawRoute(wps);

        st.className = 'status-msg ok';
        st.textContent = `✔ ${wps.length} fixes loaded`;
        $('fi-od').textContent     = `${orig} → ${dest}`;
        $('fi-cruise').textContent = `FL${fl}`;
        $('fi-route').textContent  = rte || 'DCT';
        $('sb-info').hidden = false;

    } catch(e) {
        st.className = 'status-msg err';
        st.textContent = '✖ ' + e.message;
    }
}

function drawRoute(wps) {
    if (routeLayer) { map.removeLayer(routeLayer); routeLayer = null; }
    routeLayer = L.layerGroup();

    L.polyline(wps.map(w => [w.lat, w.lon]), {
        color:'#ff9800', weight:2.5, opacity:0.85, dashArray:'6 4'
    }).addTo(routeLayer);

    const step = Math.max(1, Math.floor(wps.length / 20));
    wps.forEach((w, i) => {
        const end = i === 0 || i === wps.length-1;
        L.circleMarker([w.lat, w.lon], {
            radius: end ? 6 : 3, color: end ? '#f85149' : '#ff9800',
            fillColor: end ? '#f85149' : '#ff9800', fillOpacity:0.9, weight:1
        }).bindPopup(`<b>${w.ident}</b><br>${w.lat.toFixed(4)}°, ${w.lon.toFixed(4)}°`
            + (w.altFt ? `<br>${w.altFt.toLocaleString()} ft` : '')
        ).addTo(routeLayer);

        if (end || i % step === 0) {
            L.marker([w.lat, w.lon], {
                icon: L.divIcon({ html:`<div class="wp-label">${w.ident}</div>`, className:'', iconAnchor:[-4,8] }),
                interactive:false, zIndexOffset:500
            }).addTo(routeLayer);
        }
    });

    routeLayer.addTo(map);
    map.fitBounds(L.latLngBounds(wps.map(w => [w.lat, w.lon])), { padding:[40,40] });
}

function clearRoute() {
    if (routeLayer) { map.removeLayer(routeLayer); routeLayer = null; }
    simbriefRoute = null;
    $('sb-info').hidden = true;
    $('sb-status').className = 'status-msg';
    $('sb-status').textContent = '';
}

// ── Theme ─────────────────────────────────────────────────────
function applyTheme(t) {
    document.documentElement.dataset.theme = t;
    $('themeToggle').querySelector('.theme-icon').textContent = t === 'dark' ? '☀' : '☾';
    localStorage.setItem('doge-theme', t);
    if (trailLine) trailLine.setStyle({ color: t==='dark' ? '#388bfd' : '#0969da' });
    if (currentPos) drawWindRose(currentPos.wind_dir, currentPos.wind_spd_kts, currentPos.heading);
}

// ── DOM helper ────────────────────────────────────────────────
const $ = id => document.getElementById(id);

// ── Event wiring ──────────────────────────────────────────────
$('themeToggle').addEventListener('click', () => {
    applyTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
});

$('opt-follow').addEventListener('change', e => {
    followAc = e.target.checked;
    if (followAc && currentPos) map.setView([currentPos.lat, currentPos.lon], map.getZoom());
});

$('opt-trail').addEventListener('change', e => {
    showTrail = e.target.checked;
    if (!showTrail && trailLine) { map.removeLayer(trailLine); trailLine = null; trailPts = []; }
});

$('opt-satellite').addEventListener('change', e => {
    if (e.target.checked) { map.removeLayer(tileLayers.osm); tileLayers.sat.addTo(map); }
    else                   { map.removeLayer(tileLayers.sat); tileLayers.osm.addTo(map); }
});

$('opt-smooth').addEventListener('change', e => { smoothLerp = e.target.checked; });

$('zoom-slider').addEventListener('input', e => {
    const z = +e.target.value;
    $('zoom-val').textContent = z;
    map.setZoom(z);
});
map.on('zoom', () => {
    const z = map.getZoom();
    $('zoom-slider').value = z; $('zoom-val').textContent = z;
});

$('trail-slider').addEventListener('input', e => {
    trailMax = +e.target.value;
    $('trail-val').textContent = trailMax + ' pts';
    while (trailPts.length > trailMax) trailPts.shift();
    if (trailLine) trailLine.setLatLngs(trailPts);
});

map.on('dragstart', () => { followAc = false; $('opt-follow').checked = false; });

$('btn-center').addEventListener('click', () => {
    if (currentPos) {
        followAc = true; $('opt-follow').checked = true;
        map.setView([currentPos.lat, currentPos.lon], map.getZoom(), { animate:true });
    }
});

$('btn-load-route').addEventListener('click', () => {
    const id = $('sb-id').value.trim();
    if (!id) {
        $('sb-status').className = 'status-msg err';
        $('sb-status').textContent = 'Please enter your SimBrief Pilot ID or Username';
        return;
    }
    loadSimbrief(id);
});
$('sb-id').addEventListener('keydown', e => { if (e.key==='Enter') $('btn-load-route').click(); });
$('btn-clear-route').addEventListener('click', clearRoute);

$('opt-tod').addEventListener('change', e => {
    showTod = e.target.checked;
    if (!showTod && todMarker) { map.removeLayer(todMarker); todMarker = null; }
    if (showTod && currentPos) updateTod(currentPos);
});
$('tod-angle').addEventListener('input', e => {
    todAngle = +e.target.value;
    $('tod-angle-val').textContent = todAngle + '°';
    if (currentPos) updateTod(currentPos);
});

// ── Persistence for SimBrief ID ───────────────────────────────
$('sb-id').addEventListener('input', e => localStorage.setItem('doge-sbid', e.target.value.trim()));

// ── Boot ──────────────────────────────────────────────────────
(function init() {
    // Restore theme
    applyTheme(localStorage.getItem('doge-theme') || 'dark');
    // Restore SimBrief ID
    const sid = localStorage.getItem('doge-sbid');
    if (sid) $('sb-id').value = sid;
    // Draw blank instruments
    drawADI(0, 0);
    drawWindRose(0, 0, 0);
    // Start polling
    setConnected(false);
    poll();
})();
