// ============================================================
// script.js  –  X-Plane Moving Map front-end
//
// Phases implemented:
//  1 – Live position (lat/lon) from /api/position every 1 s
//  2 – Heading rotation + smooth interpolation (lerp)
//  3 – SimBrief route loading + route line + waypoints
//  5 – Top of Descent calculation + marker
// ============================================================

'use strict';

// ── Constants ────────────────────────────────────────────────
const API_POLL_MS   = 1000;   // poll position every 1 second
const LERP_STEPS    = 60;     // animation frames per update
const TRAIL_MAX_PTS = 500;    // max trail breadcrumbs
const NM_PER_DEGREE = 60.0;   // rough NM per degree of lat

// ft per NM at a given descent angle: dist_nm = alt_ft / (tan(deg)*6076.12)
function todDistanceNM(altFt, angleDeg) {
  const angleRad = angleDeg * Math.PI / 180;
  return altFt / (Math.tan(angleRad) * 6076.12);
}

// Great-circle distance in NM between two lat/lon points
function distanceNM(lat1, lon1, lat2, lon2) {
  const R  = 3440.065; // Earth radius in NM
  const dL = (lat2 - lat1) * Math.PI / 180;
  const dG = (lon2 - lon1) * Math.PI / 180;
  const a  = Math.sin(dL/2)**2 +
             Math.cos(lat1*Math.PI/180) * Math.cos(lat2*Math.PI/180) * Math.sin(dG/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

// Bearing in degrees from point A to point B
function bearingDeg(lat1, lon1, lat2, lon2) {
  const toR = Math.PI/180;
  const dG  = (lon2-lon1)*toR;
  const y   = Math.sin(dG)*Math.cos(lat2*toR);
  const x   = Math.cos(lat1*toR)*Math.sin(lat2*toR) -
               Math.sin(lat1*toR)*Math.cos(lat2*toR)*Math.cos(dG);
  return (Math.atan2(y,x)*180/Math.PI + 360) % 360;
}

// Move a point by distNM in bearingDeg direction (simple flat approximation)
function destinationPoint(lat, lon, distNM, brg) {
  const d  = distNM / 3440.065;           // angular distance in radians
  const bR = brg * Math.PI / 180;
  const pR = lat * Math.PI / 180;
  const newLat = Math.asin(Math.sin(pR)*Math.cos(d) +
                            Math.cos(pR)*Math.sin(d)*Math.cos(bR));
  const newLon = lon*Math.PI/180 +
                 Math.atan2(Math.sin(bR)*Math.sin(d)*Math.cos(pR),
                             Math.cos(d)-Math.sin(pR)*Math.sin(newLat));
  return [newLat*180/Math.PI, newLon*180/Math.PI];
}

// Linear interpolation for a single number
function lerp(a, b, t) { return a + (b - a) * t; }

// Shortest-path heading interpolation (handles 359→1 wrap)
function lerpHeading(a, b, t) {
  let d = ((b - a) + 540) % 360 - 180;
  return (a + d * t + 360) % 360;
}

// ── Airplane SVG (single-path, top-down view) ───────────────
function makeAircraftSVG(size = 36) {
  return `
  <svg xmlns="http://www.w3.org/2000/svg"
       width="${size}" height="${size}" viewBox="0 0 36 36">
    <!-- Body -->
    <path d="M18 2 L22 16 L36 20 L22 22 L20 34 L18 30 L16 34 L14 22 L0 20 L14 16 Z"
          fill="#58a6ff" stroke="#1a5fb4" stroke-width="1.5" stroke-linejoin="round"/>
    <!-- Nose highlight -->
    <circle cx="18" cy="6" r="2" fill="rgba(255,255,255,0.4)"/>
  </svg>`;
}

// ── Leaflet DivIcon factory ──────────────────────────────────
function makeAircraftDivIcon(headingDeg) {
  const html = `<div style="transform:rotate(${headingDeg}deg);width:36px;height:36px;">
                  ${makeAircraftSVG()}
                </div>`;
  return L.divIcon({
    html,
    className: '',
    iconSize:    [36, 36],
    iconAnchor:  [18, 18],
    popupAnchor: [0, -20]
  });
}

// ── Map initialisation ───────────────────────────────────────
const map = L.map('map', {
  center:          [51.5, -0.1],
  zoom:            12,
  zoomControl:     true,
  attributionControl: true
});

// Tile layers
const tiles = {
  osm: L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    maxZoom: 19
  }),
  satellite: L.tileLayer(
    'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    {
      attribution: '© Esri, Maxar, Earthstar Geographics',
      maxZoom: 19
    }
  )
};
tiles.osm.addTo(map);

// ── State ────────────────────────────────────────────────────
let currentPos   = null;   // { lat, lon, heading, altitude_ft, groundspeed_kts }
let targetPos    = null;   // latest value from server
let lerpFrame    = 0;      // animation counter
let startPos     = null;   // lerp start snapshot
let animId       = null;   // requestAnimationFrame id

let acMarker     = null;   // Leaflet marker for aircraft
let trailPts     = [];     // array of [lat,lon]
let trailLine    = null;   // Leaflet polyline

let routeLayer   = null;   // SimBrief route group
let todMarker    = null;   // ToD marker
let todAngleDeg  = 3;      // degrees descent angle (from slider)
let showTod      = true;

let followAircraft = true;
let showTrail      = true;
let connected      = false;
let simbriefRoute  = null; // { waypoints: [{lat,lon,ident}], origin, dest, cruise }

// ── Convenience DOM refs ─────────────────────────────────────
const $ = id => document.getElementById(id);

// ── Aircraft marker ──────────────────────────────────────────
function ensureMarker(lat, lon, hdg) {
  if (!acMarker) {
    acMarker = L.marker([lat, lon], { icon: makeAircraftDivIcon(hdg), zIndexOffset: 1000 })
                 .addTo(map)
                 .bindPopup('<b>Your Aircraft</b>');
  }
}

function updateMarker(lat, lon, hdg) {
  ensureMarker(lat, lon, hdg);
  acMarker.setLatLng([lat, lon]);
  acMarker.setIcon(makeAircraftDivIcon(hdg));
}

// ── Trail ────────────────────────────────────────────────────
function updateTrail(lat, lon) {
  trailPts.push([lat, lon]);
  if (trailPts.length > TRAIL_MAX_PTS) trailPts.shift();

  const theme = document.documentElement.dataset.theme;
  const color = theme === 'dark' ? '#58a6ff' : '#0550ae';

  if (!trailLine) {
    trailLine = L.polyline(trailPts, { color, weight: 2, opacity: 0.6 }).addTo(map);
  } else {
    trailLine.setLatLngs(trailPts);
    trailLine.setStyle({ color });
  }
}

// ── ToD marker ───────────────────────────────────────────────
function updateTodMarker(state) {
  // Remove old marker
  if (todMarker) { map.removeLayer(todMarker); todMarker = null; }
  if (!showTod || !state) return;
  if (state.altitude_ft < 100) return; // on the ground

  const distNM = todDistanceNM(state.altitude_ft, todAngleDeg);

  // Use SimBrief destination bearing if available; otherwise use current heading
  let brg = state.heading;
  if (simbriefRoute && simbriefRoute.dest) {
    brg = bearingDeg(state.lat, state.lon,
                     simbriefRoute.dest.lat,
                     simbriefRoute.dest.lon);
  }

  const [tdLat, tdLon] = destinationPoint(state.lat, state.lon, distNM, brg);

  const icon = L.divIcon({
    html:        `<div class="tod-marker-icon">T/D&nbsp;${distNM.toFixed(1)}&thinsp;NM</div>`,
    className:   '',
    iconAnchor:  [0, 10]
  });

  todMarker = L.marker([tdLat, tdLon], { icon, zIndexOffset: 900 }).addTo(map);

  $('tod-dist').textContent = distNM.toFixed(1) + ' NM';
  $('tod-brg').textContent  = Math.round(brg) + '°';
}

// ── Apply a fully-resolved aircraft state to UI + map ────────
function applyState(s) {
  updateMarker(s.lat, s.lon, s.heading);
  if (showTrail) updateTrail(s.lat, s.lon);
  if (followAircraft) map.setView([s.lat, s.lon], map.getZoom(), { animate: false });
  updateTodMarker(s);

  $('val-lat').textContent = s.lat.toFixed(5) + '°';
  $('val-lon').textContent = s.lon.toFixed(5) + '°';
  $('val-hdg').textContent = Math.round(s.heading) + '°';
  $('val-alt').textContent = Math.round(s.altitude_ft).toLocaleString() + ' ft';
  $('val-spd').textContent = Math.round(s.groundspeed_kts) + ' kts';
}

// ── Smooth interpolation animation ──────────────────────────
function startLerp(from, to) {
  if (animId) cancelAnimationFrame(animId);
  startPos  = from;
  lerpFrame = 0;

  function step() {
    lerpFrame++;
    const t = Math.min(lerpFrame / LERP_STEPS, 1);
    const s = {
      lat:             lerp(from.lat,           to.lat,           t),
      lon:             lerp(from.lon,            to.lon,           t),
      heading:         lerpHeading(from.heading, to.heading,       t),
      altitude_ft:     lerp(from.altitude_ft,    to.altitude_ft,   t),
      groundspeed_kts: lerp(from.groundspeed_kts,to.groundspeed_kts,t)
    };
    applyState(s);
    if (t < 1) animId = requestAnimationFrame(step);
    else        currentPos = to;
  }

  animId = requestAnimationFrame(step);
}

// ── Connection status helpers ────────────────────────────────
function setConnected(ok) {
  connected = ok;
  $('conn-dot').className  = 'dot ' + (ok ? 'dot-ok'  : 'dot-bad');
  $('conn-label').textContent = ok ? 'Connected' : 'Disconnected';
}

// ── Main poll loop ───────────────────────────────────────────
async function pollPosition() {
  try {
    const res  = await fetch('/api/position', { cache: 'no-store' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json();

    setConnected(true);
    $('last-update').textContent = new Date().toLocaleTimeString();

    if (currentPos) {
      startLerp(currentPos, data);
    } else {
      currentPos = data;
      applyState(data);
      // Centre map on first fix
      map.setView([data.lat, data.lon], map.getZoom());
    }

  } catch (e) {
    setConnected(false);
    console.warn('[MovingMap] poll error:', e.message);
  }

  setTimeout(pollPosition, API_POLL_MS);
}

// ── SimBrief route loading ───────────────────────────────────
async function loadSimbriefRoute(pilotId) {
  const statusEl = $('sb-status');
  statusEl.className = 'status-msg';
  statusEl.textContent = 'Loading…';

  // Clear existing route
  clearRoute();

  const url = `https://www.simbrief.com/api/xml.fetcher.php?username=${encodeURIComponent(pilotId)}&json=1`;

  try {
    const res  = await fetch(url);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json();

    if (data.fetch && data.fetch.status === 'Error') {
      throw new Error(data.fetch.message || 'SimBrief error');
    }

    // ── Parse waypoints ──────────────────────────────────────
    const fixes = data.navlog?.fix ?? [];
    const waypoints = fixes
      .filter(f => f.pos_lat !== undefined && f.pos_long !== undefined)
      .map(f => ({
        ident: f.ident || '?',
        lat:   parseFloat(f.pos_lat),
        lon:   parseFloat(f.pos_long),
        altFt: parseInt(f.altitude_feet || 0, 10)
      }));

    if (waypoints.length < 2) throw new Error('No waypoints found in plan');

    const origin = data.origin?.icao_code  || '----';
    const dest   = data.destination?.icao_code || '----';
    const cruise = data.general?.cruise_altitude || '--';
    const route  = data.general?.route_ifps || '';

    simbriefRoute = {
      waypoints,
      origin: { icao: origin,
                lat: parseFloat(data.origin?.pos_lat  || 0),
                lon: parseFloat(data.origin?.pos_long || 0) },
      dest:   { icao: dest,
                lat: parseFloat(data.destination?.pos_lat  || 0),
                lon: parseFloat(data.destination?.pos_long || 0) }
    };

    drawRoute(waypoints);

    statusEl.className   = 'status-msg ok';
    statusEl.textContent = `✔ ${waypoints.length} fixes loaded`;

    $('fi-route').textContent  = route || 'DCT';
    $('fi-od').textContent     = `${origin} → ${dest}`;
    $('fi-cruise').textContent = `FL${cruise}`;
    $('sb-info').hidden        = false;

  } catch (err) {
    statusEl.className   = 'status-msg err';
    statusEl.textContent = '✖ ' + err.message;
    console.error('[SimBrief]', err);
  }
}

function drawRoute(waypoints) {
  if (routeLayer) { map.removeLayer(routeLayer); routeLayer = null; }

  routeLayer = L.layerGroup();

  const coords = waypoints.map(w => [w.lat, w.lon]);

  // Route line
  L.polyline(coords, {
    color:   '#ff9800',
    weight:  2.5,
    opacity: 0.85,
    dashArray: '6 4'
  }).addTo(routeLayer);

  // Waypoint dots + labels (show every Nth label to avoid clutter)
  const step = Math.max(1, Math.floor(waypoints.length / 20));
  waypoints.forEach((w, i) => {
    const isEndpoint = (i === 0 || i === waypoints.length - 1);
    const radius     = isEndpoint ? 6 : 3;
    const color      = isEndpoint ? '#ff4444' : '#ff9800';

    L.circleMarker([w.lat, w.lon], {
      radius,
      color,
      fillColor:   color,
      fillOpacity: 0.9,
      weight:      1
    }).bindPopup(
      `<b>${w.ident}</b><br>` +
      `${w.lat.toFixed(4)}°, ${w.lon.toFixed(4)}°<br>` +
      (w.altFt ? `Altitude: ${w.altFt.toLocaleString()} ft` : '')
    ).addTo(routeLayer);

    if (isEndpoint || i % step === 0) {
      L.marker([w.lat, w.lon], {
        icon: L.divIcon({
          html:      `<div class="waypoint-label">${w.ident}</div>`,
          className: '',
          iconAnchor: [-4, 8]
        }),
        interactive: false,
        zIndexOffset: 500
      }).addTo(routeLayer);
    }
  });

  routeLayer.addTo(map);

  // Fit map to route
  map.fitBounds(L.latLngBounds(coords), { padding: [40, 40] });
}

function clearRoute() {
  if (routeLayer) { map.removeLayer(routeLayer); routeLayer = null; }
  simbriefRoute = null;
  $('sb-info').hidden = true;
  const statusEl = $('sb-status');
  statusEl.className   = 'status-msg';
  statusEl.textContent = '';
}

// ── Theme handling ───────────────────────────────────────────
function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  const icon = $('themeToggle').querySelector('.theme-icon');
  icon.textContent = theme === 'dark' ? '☀' : '☾';
  localStorage.setItem('theme', theme);

  // Update trail colour
  if (trailLine) {
    trailLine.setStyle({ color: theme === 'dark' ? '#58a6ff' : '#0550ae' });
  }
}

// ── Event wiring ─────────────────────────────────────────────
$('themeToggle').addEventListener('click', () => {
  const cur = document.documentElement.dataset.theme;
  applyTheme(cur === 'dark' ? 'light' : 'dark');
});

$('opt-follow').addEventListener('change', e => {
  followAircraft = e.target.checked;
  if (followAircraft && currentPos) {
    map.setView([currentPos.lat, currentPos.lon], map.getZoom());
  }
});

$('opt-trail').addEventListener('change', e => {
  showTrail = e.target.checked;
  if (!showTrail && trailLine) {
    map.removeLayer(trailLine);
    trailLine = null;
    trailPts  = [];
  }
});

$('opt-satellite').addEventListener('change', e => {
  if (e.target.checked) {
    map.removeLayer(tiles.osm);
    tiles.satellite.addTo(map);
  } else {
    map.removeLayer(tiles.satellite);
    tiles.osm.addTo(map);
  }
});

$('zoom-slider').addEventListener('input', e => {
  const z = parseInt(e.target.value, 10);
  $('zoom-val').textContent = z;
  map.setZoom(z);
});

map.on('zoom', () => {
  const z = map.getZoom();
  $('zoom-slider').value   = z;
  $('zoom-val').textContent = z;
});

// Stop auto-follow if user drags the map
map.on('dragstart', () => {
  followAircraft = false;
  $('opt-follow').checked = false;
});

$('btn-center').addEventListener('click', () => {
  if (currentPos) {
    followAircraft = true;
    $('opt-follow').checked = true;
    map.setView([currentPos.lat, currentPos.lon], map.getZoom(), { animate: true });
  }
});

$('btn-load-route').addEventListener('click', () => {
  const id = $('sb-id').value.trim();
  if (!id) {
    const s = $('sb-status');
    s.className   = 'status-msg err';
    s.textContent = 'Please enter your SimBrief Pilot ID or Username';
    return;
  }
  loadSimbriefRoute(id);
});

$('sb-id').addEventListener('keydown', e => {
  if (e.key === 'Enter') $('btn-load-route').click();
});

$('btn-clear-route').addEventListener('click', clearRoute);

$('opt-tod').addEventListener('change', e => {
  showTod = e.target.checked;
  if (!showTod && todMarker) { map.removeLayer(todMarker); todMarker = null; }
  if (showTod && currentPos) updateTodMarker(currentPos);
});

$('tod-angle').addEventListener('input', e => {
  todAngleDeg = parseFloat(e.target.value);
  $('tod-angle-val').textContent = todAngleDeg + '°';
  if (currentPos) updateTodMarker(currentPos);
});

// ── Boot ─────────────────────────────────────────────────────
(function init() {
  // Restore theme preference
  const savedTheme = localStorage.getItem('theme') || 'dark';
  applyTheme(savedTheme);

  // Restore SimBrief ID
  const savedId = localStorage.getItem('simbriefId');
  if (savedId) $('sb-id').value = savedId;

  $('sb-id').addEventListener('input', e => {
    localStorage.setItem('simbriefId', e.target.value.trim());
  });

  // Show "waiting for X-Plane" placeholder in the status bar
  setConnected(false);

  // Start polling
  pollPosition();
})();
